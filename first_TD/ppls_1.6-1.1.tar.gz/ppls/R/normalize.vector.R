`normalize.vector` <-
function(v){
    v/sqrt(sum(v^2))
}

