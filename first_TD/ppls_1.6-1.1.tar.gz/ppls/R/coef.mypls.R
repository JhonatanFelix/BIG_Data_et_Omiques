coef.mypls=function(object,...){
    return(object$coefficients)
}
